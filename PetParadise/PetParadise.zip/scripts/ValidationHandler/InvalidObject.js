﻿function InvalidObject(property, message) {
    this.property = property;
    this.message = message;
}